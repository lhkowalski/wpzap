<p>
	<label for="wpzap-options-floating-button-ativar">
		<input id="wpzap-options-floating-button-ativar" <?php echo checked($options['floating_button_active'], 'S'); ?> type="checkbox" name="wpzap_options[floating_button_active]" value="S" />Sim, mostrar botão flutuante de Contato pelo WhatsApp
	</label>
</p>