<p>
	<label for="wpzap-options-custom-style-ativar">
		<input id="wpzap-options-custom-style-ativar" <?php echo checked($options['custom_style'], 'S'); ?> type="checkbox" name="wpzap_options[custom_style]" value="S" />Sim, ativar os estilos especiais
	</label>
</p>

<p>Marque essa opção se os elementos do WPZap não ficarem bem formatados no seu tema ou se você gostar da aparência dos estilos especiais.</p>