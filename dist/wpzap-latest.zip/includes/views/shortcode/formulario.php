<div class="wpzap-form-wrap">
	<form action="<?php echo $hrefLink; ?>" method="get" target="_blank">
		<p>
			<textarea class='wpzap-form-textarea' id="wpzap-formulario-text" name="text" rows="8"><?php echo $content; ?></textarea>
		</p>
		<p><button class='wpzap-btn-inline wpzap-btn-inline-green'><?php echo $attributes['texto']; ?></button></p>
	</form>
</div>