<div class="wpzap-floating-button <?php echo $position; ?>">
	<a target="_blank" href="<?php echo $link; ?>" title="<?php echo $title; ?>">
		<img src="<?php echo $image; ?>" />
	</a>
</div>